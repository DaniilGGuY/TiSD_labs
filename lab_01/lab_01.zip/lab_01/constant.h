#ifndef CONSTANT_H__
#define CONSTANT_H__

#define MANT_LEN    35
#define K_LEN        5
#define STR_LEN     64

#endif
