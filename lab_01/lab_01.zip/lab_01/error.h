#ifndef ERROR_H__
#define ERROR_H__

#define OK             0
#define ERR_IO         1
#define ERR_EXP        2
#define ERR_INT        3
#define ERR_LEN        4
#define ERR_OVERFLOW   5
#define ERR_RES        6
#define ERR_ANS        7

#endif
