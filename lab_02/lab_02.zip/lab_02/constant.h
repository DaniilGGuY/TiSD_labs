#ifndef CONSTANT_H__
#define CONSTANT_H__

#define FILE_NAME        40
#define STREET_LEN       30
#define NAME_LEN         15
#define SURNAME_LEN      15
#define GENDER_LEN       10
#define GROUP_LEN        10
#define STR_LEN         100
#define N             10005

#endif