#!/bin/bash

rm -f ./*.exe ./*.o ./*.gcda ./*.gcov ./*.c.gcov ./*.gcno ./*.txt
