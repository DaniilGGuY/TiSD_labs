#ifndef CONSTANT_H__
#define CONSTANT_H__

#define N           5000
#define M           5000
#define FILE_NAME     60

#endif