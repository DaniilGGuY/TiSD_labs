#ifndef CONSTANT_H__
#define CONSTANT_H__

#define N              10001
#define WORD_LEN        40

#endif