#ifndef PROCESS_STRING_H__
#define PROCESS_STRING_H__

int read_str(char str[WORD_LEN + 1]);

void print_str(char *str);

void reverse_print_str(char *str);

#endif