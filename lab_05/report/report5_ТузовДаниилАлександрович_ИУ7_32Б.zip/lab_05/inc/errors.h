#ifndef ERRORS_H__
#define ERRORS_H__

#define OK           0
#define ERR_EMPTY    1
#define ERR_MEM      2
#define ERR_FULL     3
#define ERR_IO       4

#endif