#ifndef PROCESS_H__
#define PROCESS_H__

#include "tree.h"

int read_str(char **buf);

int read_int(int *val);

int read_node(tree_t **pt);

#endif