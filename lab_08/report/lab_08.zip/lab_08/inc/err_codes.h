#ifndef ERR_CODES_H__
#define ERR_CODES_H__

#define OK            0
#define ERR_IO        1
#define ERR_MEM       2
#define ERR_FILE      3

#endif